function valid(){
		var regex_email = /^[\_]*([a-z0-9]+(\.|\_*)?)+@([a-z][a-z0-9\-]+(\.|\-*\.))+[a-z]{2,6}$/;
		var regex_password = /^[a-zA-Z0-9]+$/;
		if(regex_email.test(document.getElementById('email').value)
		&& regex_password.test(document.getElementById("password").value)){
				return true;
		}else{
				return false;
		}
}

function adjustScreen(){
	var outer_wrapper = document.getElementById("outer_wrapper");
	var content_side_bar = document.getElementById("content_side_bar");
	var note_wrapper = document.getElementById("note_wrapper");
	outer_wrapper.style.width = screen.width - 80 + "px";
	outer_wrapper.style.height = (screen.height>window.innerHeight?window.innerHeight:screenheight) - 50 + "px";
	if(content_side_bar){
		content_side_bar.style.height = parseInt(outer_wrapper.style.height) - 50 + "px";
		content_side_bar.style.width = 200 + "px";
	}
	if(note_wrapper){
		note_wrapper.style.height =  parseInt(outer_wrapper.style.height) - 70 + "px";
		if(content_side_bar){
			note_wrapper.style.width =  parseInt(outer_wrapper.style.width) -  parseInt(content_side_bar.style.width) - 40 + "px";
		}else{
			note_wrapper.style.width =  parseInt(outer_wrapper.style.width) -  20 + "px";
		}
	}
}
window.onresize = adjustScreen;
