<?php
	define("DEVELOPMENT", true);
	define('ROOT_PATH', '/Users/ylan11/Sites/fg-note');
	define('SITE_URL', 'http://localhost/~ylan11/fg-note');


	if(DEVELOPMENT == true){
		error_reporting(E_ALL);
		ini_set('display_errors', 'On');
	}else{
		error_reporting(E_ALL);
		ini_set('display_errors', 'Off');
		ini_set('log_errors', 'On');
		ini_set('error_log',ROOT_PATH + '/log/error.log');
	}

	mysql_connect('localhost', 'root', '800830') && mysql_select_db('fg_note') or die(mysql_error());
?>
