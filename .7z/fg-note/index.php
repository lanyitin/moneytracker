<?php
session_start();
require_once ('configs/configure.php');
include_once ('class/Smarty.class.php');
include_once ('functions.php');
$template = new Smarty();
$template->assign('SITE_URL', SITE_URL);

if(!array_key_exists('userid', $_SESSION)){
	if(strtolower($_SERVER['REDIRECT_QUERY_STRING']) != "url=user/login"
	&& strtolower($_SERVER['REDIRECT_QUERY_STRING']) != "url=user/regist" ){
		header('location:' . SITE_URL  . '/User/login');
	}
}else{
	$template->assign('email', $_SESSION['email']);
	$template->assign('notebooks', getNBsOfUser($_SESSION['userid']));
}

if(array_key_exists("url", $_GET)){
	$urlArray = explode('/', $_GET['url']);
	require_once(strtolower($urlArray[0].".php"));
	$template->assign('tpl', strtolower($urlArray[0] . '_' . strtolower($urlArray[1]) . '.tpl'));
	if(count($urlArray)==2){
		$urlArray[1]();
	}else if(count($urlArray) == 3){
		$urlArray[1]($urlArray[2]);
	}else{
		default_function();
	}
}
$template->display('index.tpl');
?>
