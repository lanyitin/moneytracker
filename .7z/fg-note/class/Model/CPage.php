<?php
require_once("ACEntityComponent.php");
require_once("CQuery.php");
class Page extends Component implements IEntityObject{
	function __construct(){
		parent::__construct();
	}

	public function setNoteid($para_noteid){
		$this->setAttribute("noteid", $para_noteid);
	}

	public function getNoteid(){
		return $this->getAttribute("noteid");
	}

	public function setContent($para_content){
		$this->setAttribute("content", $para_content);
	}

	public function getContent($para_content){
		$this->getAttribute("content");
	}

	public function getSelectQuery($para_fields){
		//return sprintf("select %s from Page where page_number=%d", implode(",", $para_fields), $this->getId());
		$con1 = new QueryCondiction("page_number", "=", $this->getId());
		$con2 = new QueryCondiction("noteid", "=", $this->getNoteid());
		$con1->concate(QueryCondiction::_AND_, $con2);
		return new SelectQuery(get_class($this), $para_fields, $con1);
	}

	public function getInsertQuery($para_key_value_pairs){
		//return sprintf("insert into Page (%s) values (%s)", implode(",", array_keys($para_key_value_pairs)), implode(",", array_values($para_key_value_pairs)));
		return new InsertQuery(get_class($this), $para_key_value_pairs);
	}

	public function getDeleteQuery(){
		//return sprintf("delete from Page where page_number=%d and noteid=%d", $this->getId(), $this->getAttribute("noteid"));
		$con1 = new QueryCondiction("page_number", "=", $this->getId());
		$con2 = new QueryCondiction("noteid", "=", $this->getNoteid());
		$con1->concate(QueryCondiction::_AND_, $con2);
		return new DeleteQuery(get_class($this), $con1);
	}

	public function getUpdateQuery($para_key_value_pairs){
		//$set_str = "";
		//foreach($para_key_value_pairs as $key => $value){
		//	$set_str .= ($key."=".$value.",");
		//}
		//$set_str = substr($set_str, 0, -1);
		//$str = sprintf("update Page set %s where page_number=%d AND noteid=%d", $set_str, $this->getId(), $this->getAttribute("noteid"));
		//return $str;
		$con1 = new QueryCondiction("page_number", "=", $this->getId());
		$con2 = new QueryCondiction("noteid", "=", $this->getNoteid());
		$con1->concate(QueryCondiction::_AND_, $con2);
		return new UpdateQuery(get_class($this), $para_key_value_pairs, $con1);
	}
}
?>
