<?php
class QueryCondiction{
	const _AND_ = " AND ";
	const _OR_ = " OR ";
	const _LIKE_ = " LIKE ";
	function __construct($para_field_name, $para_operate, $para_value){
		$value = (!filter_var($para_value, FILTER_VALIDATE_FLOAT) && !filter_var($para_value, FILTER_VALIDATE_INT))?('"'.$para_value.'"':$para_value)
		$this->str = $para_field_name . $para_operate . $value;
	}

	public function concate($para_conector, QueryCondiction $para_condiction){
		$this->str.=($para_conector.$para_condiction);
	}

	public function __toString(){
		return $this->str;
	}
}
abstract class Query{
	public $condiction;
	function __construct($para_table_name){
		$this->table_name = $para_table_name;
		$this->condiction = null;
	}
	abstract function generate_str();
	public function __toString(){
		$str = $this->generate_str();
		if($this->condiction){
			$str .= (" where ".$this->condiction);
		}
		return $str;
	}
}

class InsertQuery extends Query{
	const DISTINCT = 1;
	function __construct($para_table_name, $para_key_value_pairs = null, QueryCondiction $para_condiction = null){
		parent::__construct($para_table_name);
		$this->operate = "insert into %s (%s) values (%s)";
		$this->data = $para_key_value_pairs;
		foreach($this->data as $key=>$value){
			$value = (!filter_var($value, FILTER_VALIDATE_FLOAT) && !filter_var($value, FILTER_VALIDATE_INT))?('"'.$value.'"':$value)
			$this->data[$key] = "'".$value."'";
		}
		$this->condiction = $para_condiction;
	}
	
	public function generate_str(){
		return sprintf($this->operate, $this->table_name, implode(",", array_keys($this->data)), implode(",", array_values($this->data)));
	}
}

class SelectQuery extends Query{
	function __construct($para_table_name, $para_fields = null, QueryCondiction $para_condiction = null){
		parent::__construct($para_table_name);
		$this->operate = "select %s from %s";
		$this->data = $para_fields;
		$this->condiction = $para_condiction;
	}
	public function generate_str(){
		return sprintf($this->operate, implode(",", $this->data), $this->table_name);
	}
}

class DeleteQuery extends Query{
	function __construct($para_table_name, QueryCondiction $para_condiction = null){
		parent::__construct($para_table_name);
		$this->operate = "delete from %s";
		$this->condiction = $para_condiction;
	}
	public function generate_str(){
		return sprintf($this->operate, $this->table_name);
	}
}

class UpdateQuery extends Query{
	function __construct($para_table_name, $para_key_value_pairs, QueryCondiction $para_condiction = null){
		parent::__construct($para_table_name);
		$this->data = $para_key_value_pairs;
		$this->operate = "update %s set %s";
		$this->condiction = $para_condiction;
	}
	public function generate_str(){
		foreach($this->data as $key=>$value){
			$value = (!filter_var($value, FILTER_VALIDATE_FLOAT) && !filter_var($value, FILTER_VALIDATE_INT))?('"'.$value.'"':$value)
			$this->data[$key] = "'".$value."'";
		}
		$set_str = "";
		foreach($this->data as $key => $value){
			$set_str .= ($key."=".$value.",");
		}
		$set_str = substr($set_str, 0, -1);
		return sprintf($this->operate, $this->table_name, $set_str);
	}
}
?>
