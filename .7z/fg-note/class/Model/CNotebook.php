<?php
require_once("ACEntityComponent.php");
class Notebook extends EntityComponent{
	function __construct(){
		parent::__construct();
		$this->setAttribute("notes", new ArrayObject());
	}

	public function setTitle($para_title){
		$this->setAttribute("title", $para_title);
	}

	public function getTitle($para_title){
		$this->getAttribute("title");
	}

	public function setUserid($para_userid){
		$this->setAttribute("userid", $para_userid);
	}

	public function getUserid($para_userid){
		$this->getAttribute("userid");
	}
}
?>
