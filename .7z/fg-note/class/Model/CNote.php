<?php
require_once("ACEntityComponent.php");
class Note extends EntityComponent{
	function __construct(){
		parent::__construct();
		$this->setAttribute("pages", new ArrayObject());
		$this->setAttribute("tags", new ArrayObject());
	}

	public function setNotebookid($para_notebookid){
		$this->setAttribute("notebookid", $para_notebookid);
	}

	public function getNotebookid($para_notebookid){
		$this->getAttribute("notebookid");
	}
}
?>
