<?php
require_once("ACEntityComponent.php");
require_once("CQuery.php");
class Tag {
	function __construct(){
		parent::__construct();
	}

	public function setName($para_name){
		$this->setAttribute("name", $para_name);
	}

	public function getName(){
		return $this->getAttribute("name");
	}
}
?>
