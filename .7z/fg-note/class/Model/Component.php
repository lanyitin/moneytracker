<?php
class Component{
	function __construct(){
		$this->attribute = new ArrayObject();
	}

	public function setAttribute($para_name, $para_value){
		if(!is_string($para_name) && $para_name == ""){
			return false;
		}
		$this->attribute->offsetSet($para_name, $para_value);
	}

	public function getAttribute($para_name){
		return $this->attribute->offsetGet($para_name);
	}

	public function setId($para_id){
		if(!is_int($para_id)){
			return false;
		}
		$this->attribute->offsetSet("id", $para_id);
	}
	
	public function getId(){
		return $this->attribute->offsetGet("id");
	}
}
?>
