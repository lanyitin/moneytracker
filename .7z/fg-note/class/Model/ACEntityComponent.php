<?php
require_once("IEntityObject.php");
require_once("Component.php");
require_once("CQuery.php");
class EntityComponent extends Component implements IEntityObject{
	public function getSelectQuery($para_fields){
		//return sprintf("select %s from %s where %sid=%d", implode(",", $para_fields), get_class($this), strtolower(get_class($this)),$this->getId());
		return new SelectQuery(get_class($this), $para_fields, new QueryCondiction(strtolower(get_class($this))."id", "=", $this->getId()));
	}

	public function getInsertQuery($para_key_value_pairs){
		//return sprintf("insert into %s (%s) values (%s)", get_class($this), implode(",", array_keys($para_key_value_pairs)), implode(",", array_values($para_key_value_pairs)));
		return new InsertQuery(get_class($this), $para_key_value_pairs);

	}
	public function getDeleteQuery(){
		//return sprintf("delete from %s where %sid=%d", get_class($this), strtolower(get_class($this)), $this->getId());
		return new DeleteQuery(get_class($this), new QueryCondiction(strtolower(get_class($this))."id", "=", $this->getId()));
	}
	public function getUpdateQuery($para_key_value_pairs){
		//$set_str = "";
		//foreach($para_key_value_pairs as $key => $value){
		//	$set_str .= ($key."=".$value.",");
		//}
		//$set_str = substr($set_str, 0, -1);
		//$str = sprintf("upadate %s set %s where %sid=%d", get_class($this), $set_str, strtolower(get_class($this)), $this->getId());
		//return $str;
		return new UpdateQuery(get_class($this), $para_key_value_pairs, new QueryCondiction(strtolower(get_class($this))."id", "=", $this->getId()));
	}
}
?>
