<?php
interface IEntityObject{
	public function getSelectQuery($para_fields);
	public function getInsertQuery($para_key_value_pairs);
	public function getDeleteQuery();
	public function getUpdateQuery($para_fields);
}
?>
