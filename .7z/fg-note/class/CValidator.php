<?php
class Vaildator{
	static public function isValidateEmail($para_email)
	{ 
		return filter_var($para_email, FILTER_VALIDATE_EMAIL);
	} 

	static public function isEmailExist($email)
	{
		if($this->isValidateEmail){
			$sql = "select userid from User where email='$email'";
			$result = mysql_query($sql) or die(mysql_error());
			$row = mysql_fetch_assoc($result);
			if(isset($row["userid"]) || $row['userid'] > 0){
				return true;
			}else{
				return false;
			}
		}else{
			return false;
		}
	}
	
	static public function isInt($para_value){
		return filter_var($para_value, FILTER_VALIDATE_INT);
	}
}
?>
