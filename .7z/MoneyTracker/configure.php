<?php
	mysql_connect("localhost", "root", "800830");
	mysql_select_db("MoneyTracker");
	error_reporting(E_ALL);
?>
