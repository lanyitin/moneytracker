<?php
	global $template;
	$template->assign("tpl_name", "rander");
	
?>
