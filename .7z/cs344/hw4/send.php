<?php
	$email_pattern = "/([A-Za-z0-9\_\-\.]{4,})+@[A-Za-z0-9.-_]+/i";
	if(preg_match($email_pattern, $_POST['from']) 
		&& mail("lanyitin800830@gmail.com", "mail from website",$_POST['content'], "From: " . $_POST['from'] . "\r\n"))
	{
		header("Location:contact.html?msg=Successful");
	}else{
		header("Location:contact.html?msg=Failed");
	}
?>
