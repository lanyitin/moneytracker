var flagStart = 1;
var flagOutOfboundary = 0;
function boundaryonmouseover(){
	flagOutOfboundary = 1;
	var d = document.getElementById("boundary1");
	do{
		if(d.className == "boundary"){
			d.style.backgroundColor = "#000000";
		}
	}while(d = d.nextSibling);
}

function startOnClick(){
	flagStart = 1;
	flagOutOfboundary = 0;
	var d = document.getElementById("boundary1");
	do{
		if(d.className == "boundary"){
			d.style.backgroundColor = "";
		}
	}while(d = d.nextSibling);
}

function endonmouseover(){
	if(flagStart){
		if(flagOutOfboundary){
			alert("You lose");
		}else{
			alert("You win");
		}
	}else{
		alert("click S to restart");
	}
	flagStart = 0;
}
	
window.onload = function (){
	document.getElementById("start").onclick = startOnClick;
	document.getElementById('end').onmouseover = endonmouseover;
	var boundaries = document.getElementsByClassName("boundary");
	for(var i = 0; i < boundaries.length; i++){
		boundaries[i].onmouseover = boundaryonmouseover;
	}
}


