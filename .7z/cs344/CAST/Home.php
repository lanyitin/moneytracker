<!DOCTYPE html> 
<html lang="en"> 
	<head>
		<link href="//www.winona.edu/styles.css" rel="stylesheet" type="text/css" />
		<link href="slides.css" rel="stylesheet" type="text/css" />
		<link rel="stylesheet" type="text/css" href="template.css" />
		<script src="//www.winona.edu/Scripts/jquery-1.3.2.min.js"></script>
		<script src="//www.winona.edu/Scripts/jquery-ui-1.7.1.custom.min.js"></script>
		<script src="//www.winona.edu/Scripts/functions.js"></script>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.5.1/jquery.min.js"></script>
		<script src="slides.min.jquery.js"></script>
		<script src="slides.js"></script>
		<title>Winona Children Advocacy Studies</title>
	
	</head>
	<body>
	<div id="page">
		<div> 
			<?php 
			print file_get_contents('http://www.winona.edu/header.asp');
			?>
		</div>
		<div id="CASTheader">
			<img src="logo2.jpg" />
		</div>
		<div id="CASTmenu">
			<table class="bmenu">
				<tr><td><a href="/" >Home</a></td></tr>
				<tr><td><a href="Faculty.php" >Faculty</a></td></tr>
				<tr><td><a href="links.php" >Links</a></td></tr>
				<tr><td><a href="#">Facilities</a></td></tr>
				<tr><td><a href="History.php">History</a></td></tr>
				<tr><td><a href="Description.php" >Description</a></td></tr>
			</table>
		</div>
		<div id="CASTcontent">
			<div id="slides">
				<div class="slides_container">
						<div><img src="photo1.png" width="760" height="500"></div>
						<div><img src="photo2.png" width="760" height="500"></div>
						<div><img src="photo3.png" width="760" height="500"></div>
				</div>
			</div>

		</div>
		<div id="CASTfooter">
			<?php 
			print file_get_contents('http://www.winona.edu/footer.asp');
			?>
		</div>
	</div>	
	</body>
</html>
