<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"> 
<html xmlns="http://www.w3.org/1999/xhtml"> 
	<head>
		<link href="//www.winona.edu/styles.css" rel="stylesheet" type="text/css" />
		<script type="text/javascript" src="//www.winona.edu/Scripts/jquery-1.3.2.min.js"></script>
		<script type="text/javascript" src="//www.winona.edu/Scripts/jquery-ui-1.7.1.custom.min.js"></script>
		<script type="text/javascript" src="//www.winona.edu/Scripts/functions.js"></script>
		<link rel="stylesheet" type="text/css" href="template.css" />
		<title>History | Children Advocacy Studies</title>
	</head>
	<body>
	<div id="page">
		<div> 
			<?php 
			print file_get_contents('http://www.winona.edu/header.asp');
			?>
		</div>
		<div id="CASTheader">
			<img src="images/logo.jpg" />
		</div>
		<div id="CASTmenu">
			<table class="bmenu">
				<tr><td><a href="Home.php" >Home</a></td></tr>
				<tr><td><a href="Faculty.php" >Faculty</a></td></tr>
				<tr><td><a href="Links.php" >Links</a></td></tr>
				<tr><td><a href="#" >Facilities</a></td></tr>
				<tr><td><a href="History.php" >History</a></td></tr>
				<tr><td><a href="Description.php" >Description</a></td></tr>
			</table>
		</div>
		<div id="CASTcontent">
			<h1>Development of the National Child Protection Training Center</h1>
			<p>In 2003 APRI entered into an historic relationship with Winona State University (WSU) to create the National Child Protection Training Center (NCPTC). 
NCPTC has served as an advisor to WSU in the creation of a model undergraduate curriculum to better prepare future child protection workers, law enforcement 
officers, and other child-serving professionals. NCPTC provides ongoing training, technical assistance and publications to child protection attorneys 
and other professionals who are already inthe field of civil child protection.
			</p>
			<br/>
			<h1>Development of the Curriculum</h1>
			<ul>
				<li> Fall, 2003, WSU NCPTC Advisory Council formed</li>
				<li>January 2004, Extensive review of the literature and hermeneutic analysis of the results</li>
				<li> April 2004, Review of a draft of the curriculum by local, state and national experts in focused group meetings</li>
			</ul>
		</div>
		<div id="CASTfooter">
			<?php 
			print file_get_contents('http://www.winona.edu/footer.asp');
			?>
		</div>
	</div>	
	</body>
</html>
