<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"> 
<html xmlns="http://www.w3.org/1999/xhtml"> 
	<head>
		<link href="//www.winona.edu/styles.css" rel="stylesheet" type="text/css" />
		<script type="text/javascript" src="//www.winona.edu/Scripts/jquery-1.3.2.min.js"></script>
		<script type="text/javascript" src="//www.winona.edu/Scripts/jquery-ui-1.7.1.custom.min.js"></script>
		<script type="text/javascript" src="//www.winona.edu/Scripts/functions.js"></script>
		<link rel="stylesheet" type="text/css" href="template.css" />
		<title>Faculty | Child Advocacy Studies Training</title>
	</head>
	<body>
	<div id="page">
		<div> 
			<?php 
			print file_get_contents('http://www.winona.edu/header.asp');
			?>
		</div>
		<div id="CASTheader">
			<img src="images/Logo.jpg" />
		</div>
		<div id="CASTmenu">
			<table class="bmenu">
				<tr><td><a href="Home.php" >Home</a></td></tr>
				<tr><td><a href="Faculty.php" >Faculty</a></td></tr>
				<tr><td><a href="Links.php" >Links</a></td></tr>
				<tr><td><a href="#" >Facilities</a></td></tr>
				<tr><td><a href="History.php" >History</a></td></tr>
				<tr><td><a href="Description.php" >Description</a></td></tr>
			</table>
		</div>
		<div id="CASTcontent">
			<h2>Angie Scott Dixon</h2><br>
			<h3>Program Director</h3><br>
			<h3>(507) 457-2892</h3><br>
			<h3>ascott@winona.edu</h3><br>
		</div>
		<div id="CASTfooter">
			<?php 
			print file_get_contents('http://www.winona.edu/footer.asp');
			?>
		</div>
	</div>	
	</body>
</html>
