<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"> 
<html xmlns="http://www.w3.org/1999/xhtml"> 
	<head>
		<link href="//www.winona.edu/styles.css" rel="stylesheet" type="text/css" />
		<script type="text/javascript" src="//www.winona.edu/Scripts/jquery-1.3.2.min.js"></script>
		<script type="text/javascript" src="//www.winona.edu/Scripts/jquery-ui-1.7.1.custom.min.js"></script>
		<script type="text/javascript" src="//www.winona.edu/Scripts/functions.js"></script>
		<link rel="stylesheet" type="text/css" href="template.css" />
		<title>Links | Child Advocacy Studies Training</title>
	</head>
	<body>
	<div id="page">
		<div> 
			<?php 
			print file_get_contents('http://www.winona.edu/header.asp');
			?>
		</div>
		<div id="CASTheader">
			<img src="Images/Logo.jpg" />
		</div>
		<div id="CASTmenu">
			<table class="bmenu">
				<tr><td><a href="Home.php" >Home</a></td></tr>
				<tr><td><a href="Faculty.php" >Faculty</a></td></tr>
				<tr><td><a href="Links.php" >Links</a></td></tr>
				<tr><td><a href="#" >Facilities</a></td></tr>
				<tr><td><a href="History.php" >History</a></td></tr>
				<tr><td><a href="Description.php" >Description</a></td></tr>
			</table>
		</div>
		<div id="CASTcontent">
			<h1>Links</h1>
			<ul>
				<li><a href="http://www.apsac.org">American Professional Society on the Abuse of Children</a></li>
				<li><a href="http://www.childhelpusa.org">Childhelp USA</a></li>
				<li><a href="http://www.childlures.org">Child Lures Prevention</a></li>
				<li><a href="http://www.cwla.org">Child Welfare League of America</a></li>
				<li><a href="http://www.ispcan.org">International Society on the Prevention of Child Abuse and Neglect</a></li>
				<li><a href="http://www.nationalcasa.org">National CASA</a></li>
				<li><a href="http://www.nca-online.org">National Children's Alliance</a></li>
				<li><a href="http://www.missingkids.org">The Center for Missing &amp; Exploited Children</a></li>
				<li><a href="http://www.icmec.org">The International Center for Missing &amp; Exploited Children</a></li>
				<li><a href="http://www.nationalcac.org/">The National Children's Advocacy Center</a></li>
				<li><a href="http://www.ndaa-apri.org/apri/programs/ncptc/ncptc_home.html">National Child Protection Training Center</a></li>
			</ul>
			<br>
			<h2>Regional CAC's:</h2>
			<ul>
				<li><a href="http://www.mrcac.org">Midwest</a></li>
				<li><a href="http://www.nca-online.org/nrcac/index.html">Northeast</a></li>
				<li><a href="http://www.nca-online.org/wrcac/index.html">Western</a></li>
			</ul>
		</div>
		<div id="CASTfooter">
			<?php 
			print file_get_contents('http://www.winona.edu/footer.asp');
			?>
		</div>
	</div>	
	</body>
</html>
