<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"> 
<html xmlns="http://www.w3.org/1999/xhtml"> 
	<head>
		<link href="//www.winona.edu/styles.css" rel="stylesheet" type="text/css" />
		<script type="text/javascript" src="//www.winona.edu/Scripts/jquery-1.3.2.min.js"></script>
		<script type="text/javascript" src="//www.winona.edu/Scripts/jquery-ui-1.7.1.custom.min.js"></script>
		<script type="text/javascript" src="//www.winona.edu/Scripts/functions.js"></script>
		<link rel="stylesheet" type="text/css" href="template.css" />
	</head>
	<body>
	<div id="page">
		<div> 
			<?php 
			print file_get_contents('http://www.winona.edu/header.asp');
			?>
		</div>
		<div id="CASTheader">
			<img src="logo2.jpg" />
		</div>
		<div id="CASTmenu">
			<table class="bmenu">
				<tr><td><a href="template.html" >Home</a></td></tr>
				<tr><td><a href="template.html" >Faculty</a></td></tr>
				<tr><td><a href="template.html" >Links</a></td></tr>
				<tr><td><a href="template.html" >Facilities</a></td></tr>
				<tr><td><a href="template.html" >History</a></td></tr>
				<tr><td><a href="template.html" >Description</a></td></tr>
			</table>
		</div>
		<div id="CASTcontent">
			<p>This course is the introductory course for child advocacy studies. This course covers the history, comparative perspectives, the legal framework, responses to child maltreatment, the skills necessary to do the work, other pertinent issues pertaining to child maltreatment and child advocacy, and the future. The field of child maltreatment is fraught with controversy. Much of the class focuses on these controversies. The approach of the course will be from a variety of diverse, professional perspectives including the perspectives of a prosecuting attorney versus a defense attorney. The course is designed for students majoring in criminal justice, education, social work, sociology, psychology, nursing, paralegal, or other areas where knowledge of child maltreatment and advocating for children might be necessary. Much of the work will be hands-on.
			</p>
		</div>
		<div id="CASTfooter">
			<?php 
			print file_get_contents('http://www.winona.edu/footer.asp');
			?>
		</div>
	</div>	
	</body>
</html>