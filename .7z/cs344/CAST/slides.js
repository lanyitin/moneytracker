function dot(){
	$(".pagination li a").html("<img src=\"gray_dot.png\">")
	$(".pagination .current a").html("<img src=\"purple_dot.png\">")
}

setInterval(dot, 500);

$(function(){
	$('#slides').slides({
		preload: true,
		generateNextPrev: true,
	});
	$(".prev").html("<img src=\"arrow-prev.png\">");
	$(".next").html("<img src=\"arrow-next.png\">");

});
