<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"> 
<html xmlns="http://www.w3.org/1999/xhtml"> 
	<head>
		<link href="//www.winona.edu/styles.css" rel="stylesheet" type="text/css" />
		<script type="text/javascript" src="//www.winona.edu/Scripts/jquery-1.3.2.min.js"></script>
		<script type="text/javascript" src="//www.winona.edu/Scripts/jquery-ui-1.7.1.custom.min.js"></script>
		<script type="text/javascript" src="//www.winona.edu/Scripts/functions.js"></script>
		<link rel="stylesheet" type="text/css" href="TEST.css" />
		<title>Course Description | Winona Children Advocacy Studies</title>
	</head>
	<body>
	<div id="page">
		<div> 
			<?php 
			print file_get_contents('http://www.winona.edu/header.asp');
			?>
		</div>
		<div id="CASTheader">
			<img src="logo2.jpg" />
		</div>
		<div id="CASTmenu">
			<table class="bmenu">
				<tr><td><a href="template.html" >Home</a></td></tr>
				<tr><td><a href="template.html" >Faculty</a></td></tr>
				<tr><td><a href="template.html" >Links</a></td></tr>
				<tr><td><a href="template.html" >Facilities</a></td></tr>
				<tr><td><a href="template.html" >History</a></td></tr>
				<tr><td><a href="template.html" >Description</a></td></tr>
			</table>
		</div>
		<div id="CASTcontent">
			<h3>CAST 301 - Child Advocacy Studies 1: Perspectives on Child Maltreatment and Child Adv - 3 S.H.</h3>
			<p>&nbsp;&nbsp;&nbsp;&nbsp;This course is the introductory course for the Child Advocacy Studies Program. The purpose of the course is to introduce the role of the advocate for the maltreated child. The course is designed for students majoring in criminal justice, education, social work, sociology, psychology, nursing, paralegal, or other areas where knowledge of child abuse and advocating for children will be necessary. Students will be introduced to different approaches to child abuse intervention, including interdisciplinary models, and will discuss issues related to child abuse from a variety of professional perspectives. This course satisfies the University Studies Program and Diversity-Critical Analysis requirement. No prerequisites. Grade only, Offered twice every three years.</p><br/>
			<h3>CAST 302 - Global Child Advocacy Issues - 3 S.H.</h3>
			<p>&nbsp;&nbsp;&nbsp;&nbsp;This course is a core course for child advocacy studies minor. The purpose of this course is to prepare students to recognize child advocacy issues around the world. The course is designed for students majoring in criminal justice, education, social work, sociology, psychology, nursing, paralegal, or other areas where knowledge of child maltreatment and advocating for children will be necessary. Multidisciplinary approaches to advocacy in different countries throughout the world will be presented and discussed. Prerequisites: none. Offered once a year.</p><br/>
			<h3>CAST 401 - Child Advocacy Studies II: Professional and System Response to Child Abuse - 4 S.H.</h3>
			<p>&nbsp;&nbsp;&nbsp;&nbsp;This course focuses on the responses of professionals to allegations of child maltreatment. The purpose is to expand the student's knowledge and skills in identifying, investigating, and prosecuting child maltreatment. The course is designed for students majoring in criminal justice, education, social work, sociology, psychology, nursing, paralegal, and other areas in which knowledge of child maltreatment investigation and advocacy are necessary. Students will receive competency-based skills training such as forensic interviewing, documentation, and so on. Recommended prerequisites: Developmental psychology and communication courses.</p><br/>
			<h3>CAST 402 - Child Advocacy Studies III: Responding to the Survivor - 4 S.H.</h3> 
			<p>&nbsp;&nbsp;&nbsp;&nbsp;The purpose of this course is to prepare students to recognize the effects of child maltreatment and to apply intervention strategies for children and their families. Multidisciplinary approaches to prevention, advocacy, and treatment of child maltreatment survivors will be presented and discussed. The course is designed for students majoring in criminal justice, education, social work, sociology, psychology, nursing, paralegal, and other areas where knowledge of child maltreatment and advocating for children will be necessary. The experiential lab for this course involves courtroom observation and interaction with children. Prerequisites: CAST 301, CAST 401, or instructor's permission.</p><br/>
			<h3>CAST 405 - Gender, Violence and Society - 4 S.H.</h3>
			<p>&nbsp;&nbsp;&nbsp;&nbsp;This course introduces students to the roots of gender-based violence, the political and cultural structures that perpetuate it, and explores how this violence might be brought to an end. Students will investigate the local and global impact of violence; how gendered violence intersects with race, class, sexuality, age, physical ability and the oppressions that are linked to these identities; and strategies for addressing gender-based violence. The overlap between gender-based violence and child abuse and neglect will be addressed under each topic. As part of the class, students will complete a 45-hour advocacy training (plus 15 hours of volunteer advocacy work) offered in partnership with the Women's Resource Center of Winona. Course time will be divided between 2 credits of lab and 2 credits of theory. Prerequisites: CAST 301 or consent of instructor. Offered every fall semester.</p><br/>
			<h3>CAST 407 - CAST Capstone Experience - 4 S.H.</h3>
			<p>&nbsp;&nbsp;&nbsp;&nbsp;Intense site-based experience of student's choice designed to encapsulate the essence of baccalaureate professional role development in an internship experience. This synthesis course allows the student to expand their understanding of major concepts of child advocacy, experiential learning, and evidenced based practice in a setting of their choice. A multidisciplinary approach will be emphasized as students focus on ethical decision-making and cultural sensitivity with clients in a community location. Students work with preceptors in agencies and develop a project addressing a need within that agency. Prerequisites: CAST 301, CAST 401, CAST 402 or permission of instructor. Offered twice a year.</p><br/>
		</div>
		<div id="CASTfooter">
			<?php 
			print file_get_contents('http://www.winona.edu/footer.asp');
			?>
		</div>
	</div>	
	</body>
</html>
