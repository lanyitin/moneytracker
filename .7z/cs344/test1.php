<?php
	function daysInMonth($month){
		if($month == 2){
			return 28;
		}else{
			if( ($month % 2 == 1 && $month <= 7) || ($month % 2 == 0 && $month >= 8) ){
				return 31;
			}else{
				return 30;
			}
		}
	}
	function inMonth($month){
		$map = array("January","February","March","April","May","June","July","Augest","September","October","November","December");
		echo "<p>The month of ".$map[$month - 1]." is the $month<sup>th</sup> of the year abd it has <em>".daysInMonth($month)."<em> days in it.</p>";
	}
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-*">
	</head>
	<body>
		<?php 
			for($month = 1; $month <= 12; $month++){
				inMonth($month);
			}
			echo "<h1>following line is generated randomly</h1>";
			echo inMonth(rand(1, 12));
		 ?>
	</body>
</html>
	
