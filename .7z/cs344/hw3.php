<?php
	function insideOut($array){
		if(is_array($array)){
			$output_array = array();
			$count = count($array);
			$centerIndex = ($count / 2) - 1;
			for($i = $centerIndex; $i >= 0; $i--){
				$output_array[] = $array[$i];
			}
			for($i = $count - 1; $i >= $centerIndex + 1; $i--){
				$output_array[] = $array[$i];
			}
			return $output_array;
		}
	}
	$str_array = file("words.txt");
	$pro_array = insideOut($str_array);
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>PHP function - insideOut</title>
		<style type="text/css">
			body{
				margin:auto;
				padding:50px;
				background-color:#333333;
				text-align:center;
				color:#FFFFFF;
			}
			#description{
				text-align:left;
			}
			#description em{
				color:#AA9999;
			}
			#output{
				text-align:right;
			}
		</style>
	</head>
	<body>
		<h1>PHP function - insideOut</h1>
		<div id="description">
			<p>Write a PHP program that reads in a file of words and prints them out in "inside out" order.</p>
			<p>Input should be a multi-line file of words, in a file named <em>words.txt</em></p>
			<p>Output should be a web page of the words in their initial order and their "inside out" order.</p>
		</div>
		<div id="output">
			<p><?php var_dump($str_array)?></p>
			<p><?php var_dump($pro_array)?></p>
		</div>
	</body>
</html>
